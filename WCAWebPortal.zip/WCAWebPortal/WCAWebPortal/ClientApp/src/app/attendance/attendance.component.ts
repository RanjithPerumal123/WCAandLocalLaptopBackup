import { Component, Inject } from '@angular/core';
import { HttpClient, HttpParams } from '@angular/common/http';

@Component({
  selector: 'app-attendance',
  templateUrl: './attendance.component.html'
})
export class AttendanceComponent {
  public students: any[];
  public selectedstudents: any[];
  public _baseUrl: string;
  public disableSubmit = true;
  searchByDate: Date;
  searchByClass: number;
  classDetails = [
  { label: "Select Class", value: null },
  { label: "U13", value: 1 },
  { label: "U16", value: 2 },
  { label: "U19", value: 3 }
];
  constructor(public http: HttpClient, @Inject('BASE_URL') baseUrl: string) {
    this._baseUrl = baseUrl;
  }
  fetchStudentDetails(date, className) {
    if (this.searchByClass && this.searchByDate) {
      let params = new HttpParams();
      params = params.append('date', this.searchByDate.toJSON().substring(0, 10));
      params = params.append('classId', this.searchByClass.toString());
      this.http.get(this._baseUrl + 'attendance').subscribe((result: any) => {
        this.students = result;
        this.disableSubmit = false;
      }, error => console.error(error));
    }
  }
  submitAttendance() {
    this.disableSubmit = true;
    this.http.post(this._baseUrl + 'attendance/saveattendance', this.students).subscribe((result: any) => {
      this.students = result;
      console.log('Update Successfull!!')
      this.disableSubmit = false;
    }, error => console.error(error));
    console.log(this.students)
  }
  selectStudent($event, student) {
    if ($event && student) {     
      if ($event.target.checked) {
        student.isAttendanceFlag = true;
      } else {
        student.isAttendanceFlag = false;
      }

    }
  }
}


import { HttpClient, HttpHeaders, HttpParams } from '@angular/common/http';
import { Component, Inject, ViewChild } from '@angular/core';
import { Table } from 'primeng/table';
 

@Component({
  selector: 'app-student-component',
  templateUrl: './student.component.html'
})
export class StudentComponent {
   

  //students = [
  //  {
  //    "studentId": "61174f2dc236f83f11d7d16e",
  //    "isActive": false,
  //    "age": 11,
  //    "firstName": "William",
  //    "lastName": " Hodges",
  //    "fatherName": "Rose",
  //    "motherName": " Chandler",
  //    "gender": "male",
  //    "className": "BICOL",
  //    "email": "rosechandler@bicol.com",
  //    "phone": "+1 (908) 465-2474"
  //  },
  //  {
  //    "studentId": "61174f2dde946bc80efaa0b6",
  //    "isActive": true,
  //    "age": 9,
  //    "firstName": "Ball",
  //    "lastName": " Durham",
  //    "fatherName": "Schultz",
  //    "motherName": " Nolan",
  //    "gender": "male",
  //    "className": "ROCKLOGIC",
  //    "email": "schultznolan@rocklogic.com",
  //    "phone": "+1 (841) 458-2896"
  //  },
  //  {
  //    "studentId": "61174f2d0952960cdcde468d",
  //    "isActive": false,
  //    "age": 10,
  //    "firstName": "Hurley",
  //    "lastName": " Simpson",
  //    "fatherName": "Charmaine",
  //    "motherName": " Bullock",
  //    "gender": "female",
  //    "className": "EMOLTRA",
  //    "email": "charmainebullock@emoltra.com",
  //    "phone": "+1 (882) 562-3578"
  //  },
  //  {
  //    "studentId": "61174f2d769455b2b91eb9b7",
  //    "isActive": false,
  //    "age": 7,
  //    "firstName": "Selma",
  //    "lastName": " Patterson",
  //    "fatherName": "Rae",
  //    "motherName": " Forbes",
  //    "gender": "female",
  //    "className": "PHUEL",
  //    "email": "raeforbes@phuel.com",
  //    "phone": "+1 (871) 579-2345"
  //  },
  //  {
  //    "studentId": "61174f2d8e7b51fab58c6e98",
  //    "isActive": true,
  //    "age": 8,
  //    "firstName": "Conley",
  //    "lastName": " Houston",
  //    "fatherName": "Howard",
  //    "motherName": " Dominguez",
  //    "gender": "male",
  //    "className": "JIMBIES",
  //    "email": "howarddominguez@jimbies.com",
  //    "phone": "+1 (880) 467-2522"
  //  },
  //  {
  //    "studentId": "61174f2d08f6033348a6e7f9",
  //    "isActive": false,
  //    "age": 18,
  //    "firstName": "Peterson",
  //    "lastName": " Little",
  //    "fatherName": "Carissa",
  //    "motherName": " Mercer",
  //    "gender": "female",
  //    "className": "HYPLEX",
  //    "email": "carissamercer@hyplex.com",
  //    "phone": "+1 (926) 487-3847"
  //  }
  //];
  students: any = {};
  _baseUrl: string;
  selectedStudents: any[];
  representatives: any[];
  statuses: any[];
  loading: boolean = true;
  newStudent: boolean;
  editStudentId: number;
  student: any = {};
  displayDialog: boolean = false;
  displayDeleteDialog: boolean = false;
  classDetails: any = {};
  selectedEmploye: string = "";
  @ViewChild('dt', { static: false }) table: Table;
  constructor(public http: HttpClient, @Inject('BASE_URL') baseUrl: string) {
    this._baseUrl = baseUrl;
    
    this.http.get(this._baseUrl + 'student').subscribe((result: any) => {
      this.students = result;
      this.loading = false;
    }, error => console.error(error));
  

    this.classDetails = [
      { label: "Select Class", value: null },
      { label: "U13", value: 1 },
      { label: "U16", value: 2 },
      { label: "U19", value: 3 }
    ];
  }

  
  ngOnInit() {
  }

  ngAfterViewInit() {

  }

  showDialogToAdd() {
    this.newStudent = true;
    this.editStudentId = 0;
    this.student = {};
    this.displayDialog = true;
  }


  showDialogToEdit(student: any) {
    this.newStudent = false;
    this.student.studentId = student.studentId;
    this.student.firstName = student.firstName;
    this.student.lastName = student.lastName;
    this.student.dateOfBirth = student.dateOfBirth;
    this.student.fatherFullName = student.fatherFullName;
    this.student.motherFullName = student.motherFullName;
    this.student.emailId = student.emailId;
    this.student.phoneNumber = student.phoneNumber;
    this.student.abountMe = student.abountMe;
    this.student.wantsToBe = student.wantsToBe;
    this.displayDialog = true;
  }

  save() {
    console.log(this.student);    
    this.http.post(this._baseUrl + 'student/savestudent', this.student).subscribe((result: any) => {
      this.students = result;
      console.log('Update Successfull!!')
     
    }, error => console.error(error));
    console.log(this.students)
    //this.contactService.saveContact(this.contact)
    //  .subscribe(response => {
    //    this.contact.contactId > 0 ? this.toastrService.success('Data updated Successfully') :
    //      this.toastrService.success('Data inserted Successfully');
    //    this.loadData();
    //  });
    this.displayDialog = false;
  }

  cancel() {
    this.student = {};
    this.displayDialog = false;
  }


  showDialogToDelete(student: any) {
    this.student = student;
    this.editStudentId = student.studentId;
    this.displayDeleteDialog = true;
  }

  okDelete(isDeleteConfirm: boolean) {
    if (isDeleteConfirm) {
      this.http.post(this._baseUrl + 'student/deletestudent', this.student.studentId).subscribe((result: any) => {
        this.students = result;
        console.log('Update Successfull!!')

      }, error => console.error(error));
      console.log(this.students)
    }
    this.displayDeleteDialog = false;
  }
}

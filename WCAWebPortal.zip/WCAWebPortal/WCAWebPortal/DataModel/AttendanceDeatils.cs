﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Threading.Tasks;

namespace WCAWebPortal.DataModel
{
    [Table("AttendanceDeatils")]
    public class AttendanceDeatils
    {      
        [Key]
        [DatabaseGenerated(DatabaseGeneratedOption.Identity)]
        public int? AttendanceId { get; set; }
        public int StudentId { get; set; }
        public int ClassId { get; set; }

        
        public string ClassDate { get; set; }

        
        public DateTime? ClassStartTime { get; set; }

       
        public DateTime? ClassEndTime { get; set; }

       
        public DateTime? CreatedDateTime { get; set; }
        public string CreatedBy { get; set; }
        public DateTime? UpdatedDateTime { get; set; }
        public string UpdatedBy { get; set; }
        public string IsActive { get; set; }
    }
}

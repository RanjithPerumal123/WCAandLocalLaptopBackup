﻿using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Threading.Tasks;

namespace WCAWebPortal.DataModel
{
    [Table("StudentDetails")] 
    public class StudentDetails
    {

        [Key]
        public int StudentId { get; set; }
        public int ClassId { get; set; }
        public string FirstName { get; set; }
        public string LastName { get; set; }
        public string FatherFullName { get; set; }
        public string MotherFullName { get; set; }
        public DateTime DateOfBirth { get; set; }
        public string EmailId { get; set; }
        public string PhoneNumber { get; set; }
        public string WantsToBe { get; set; }
        public string AbountMe { get; set; }
        public DateTime? CreatedDateTime { get; set; } 
        public string CreatedBy { get; set; } 
        public DateTime? UpdatedDateTime { get; set; } 
        public string UpdatedBy { get; set; }         
        public string IsActive { get; set; }
    }
}

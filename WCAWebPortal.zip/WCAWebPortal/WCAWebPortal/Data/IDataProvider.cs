﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text.Json;
using System.Threading.Tasks;
using WCAWebPortal.DataModel;
using WCAWebPortal.Models;

namespace WCAWebPortal.Data
{
    public interface IDataProvider : IDisposable
    {
        public UserLogin GetUserLogin(string userid);

        public List<StudentDetails> GetStudentDetails();

        public StudentDetails SaveStudentDetails(StudentDetails studenDetails);

        public List<ClassDetails> GetClassDetails();

        public List<StudentAttendance> GetAttendanceDetails();

        public List<StudentAttendance> SaveAttendanceDetails(JsonElement attendanceDeatils);

    }
}

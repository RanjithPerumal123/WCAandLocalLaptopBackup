﻿using Microsoft.Data.SqlClient;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Data.Entity;
using System.Data.Entity.Core.Objects;
using System.Data.Entity.Infrastructure;
using System.Linq;
using System.Text.Json;
using System.Text.Json.Serialization;
using System.Threading.Tasks;
using WCAWebPortal.DataModel;
using WCAWebPortal.Models;

namespace WCAWebPortal.Data
{
    public class DataProvider : IDataProvider
    {
        private readonly DbContextHelp _context;
        public DataProvider(DbContextHelp dbContextHelp)
        {
            this._context = dbContextHelp;
        }
        public UserLogin GetUserLogin(string userid)
        {
            return _context.UserLogins.Where(x => x.UserId == userid).FirstOrDefault();
        }

        public List<StudentDetails> GetStudentDetails()
        {
            return _context.StudentDetails.ToList();
        }

        public StudentDetails SaveStudentDetails(StudentDetails response)
        {
            //var options = new JsonSerializerOptions();
            //options.PropertyNameCaseInsensitive = true;
            //options.Converters.Add(new JsonStringEnumConverter());
            //var response = JsonSerializer.Deserialize<StudentDetails>(studenDetails.ToString(), options);

            var currentDate = DateTime.UtcNow;
            var std = new StudentDetails()
            {
                ClassId = response.ClassId,
                FirstName = response.FirstName,
                LastName = response.LastName,
                FatherFullName = response.FatherFullName,
                MotherFullName = response.MotherFullName,
                DateOfBirth = Convert.ToDateTime(response.DateOfBirth).ToUniversalTime(),
                EmailId = response.EmailId,
                PhoneNumber = response.PhoneNumber,
                WantsToBe = response.WantsToBe,
                AbountMe = response.AbountMe,               
                IsActive = "1"
            };
            if (std.StudentId > 0)
            {
                std.UpdatedDateTime = currentDate;
                std.UpdatedBy = "Ranjith";
                _context.Update(std);
            }
            else
            {
                std.CreatedDateTime = currentDate;
                std.CreatedBy = "Ranjith";
                _context.Add(std);//.State = Microsoft.EntityFrameworkCore.EntityState.Modified;

            }

            _context.SaveChanges();
            response.StudentId = std.StudentId;

            return response;
        }



        public List<ClassDetails> GetClassDetails()
        {
            return _context.ClassDetails.ToList();
        }

        public List<StudentAttendance> GetAttendanceDetails()
        {
            List<StudentAttendance> list = new List<StudentAttendance>();
            string sql = "EXEC GetAttendanceDeatils";
            list = _context.StudentAttendance.FromSqlRaw(sql).ToList();
            return list;
        }
        public List<StudentAttendance> SaveAttendanceDetails(JsonElement attendanceDetails)
        {
            var options = new JsonSerializerOptions();
            options.PropertyNameCaseInsensitive = true;
            options.Converters.Add(new JsonStringEnumConverter());
            var response = JsonSerializer.Deserialize<List<StudentAttendance>>(attendanceDetails.ToString(), options);

            foreach (StudentAttendance sd in response)
            {
                if (sd.AttendanceId == null && sd.IsAttendanceFlag)
                {
                    var currentDate = DateTime.UtcNow;
                    var std = new AttendanceDeatils()
                    {
                        StudentId = sd.StudentId,
                        ClassId = sd.ClassId,
                        CreatedDateTime = currentDate,
                        ClassStartTime = currentDate,
                        ClassEndTime = currentDate,
                        CreatedBy = "Ranjith",
                        IsActive = "1"
                    };
                    _context.Add(std);//.State = Microsoft.EntityFrameworkCore.EntityState.Modified;
                    _context.SaveChanges();
                    sd.AttendanceId = std.AttendanceId;
                }

                if (sd.AttendanceId != null && sd.IsAttendanceFlag == false)
                {
                    var std = new AttendanceDeatils()
                    {
                        AttendanceId = sd.AttendanceId
                    };
                    _context.Remove(std);//.State = Microsoft.EntityFrameworkCore.EntityState.Modified;
                    _context.SaveChanges();
                    sd.AttendanceId = null;
                }

            }
            return response;
        }



        private bool _disposed;

        protected virtual void Dispose(bool disposing)
        {
            if (!_disposed)
            {
                if (disposing)
                {
                    _context.Dispose();
                }
            }
            _disposed = true;
        }

        public void Dispose()
        {
            Dispose(true);
            GC.SuppressFinalize(this);
        }
    }
}

﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;
using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text.Json;
using System.Text.Json.Serialization;
using System.Threading.Tasks;
using WCAWebPortal.Data;
using WCAWebPortal.DataModel;
using WCAWebPortal.Models;

namespace WCAWebPortal.Controllers
{
    [ApiController]
    [Route("Class")]
    public class ClassController : ControllerBase
    {
        private readonly ILogger<AttendanceController> _logger;
        IDataProvider _dataProvider;

        public ClassController(ILogger<AttendanceController> logger, IDataProvider dataProvider)
        {
            _logger = logger;
            _dataProvider = dataProvider;
        }

        [HttpGet]
        public IEnumerable<ClassDetails> Get()
        {
            var result = _dataProvider.GetClassDetails();
            return result; 
        }

        [HttpPost]
        [Route("SaveClass")]
        public IEnumerable<StudentAttendance> SaveAttendance([FromBody] JsonElement attendanceDeatils)
        {   
            var result = _dataProvider.SaveAttendanceDetails(attendanceDeatils);
            return result;

        } 
    }



}

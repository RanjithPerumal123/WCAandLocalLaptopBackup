﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;
using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text.Json;
using System.Text.Json.Serialization;
using System.Threading.Tasks;
using WCAWebPortal.Data;
using WCAWebPortal.DataModel;

namespace WCAWebPortal.Controllers
{
    [ApiController]
    [Route("student")]
    public class StudentController : ControllerBase
    {
        private readonly ILogger<StudentController> _logger;
        IDataProvider _dataProvider;
        public StudentController(ILogger<StudentController> logger, IDataProvider dataProvider)
        {
            _logger = logger;
            _dataProvider = dataProvider;
        }

        [HttpGet]
        public IEnumerable<StudentDetails> Get()
        {
            var result = _dataProvider.GetStudentDetails();
            return result; 
        }

        [HttpPost]
        [Route("savestudent")]
        public IEnumerable<StudentDetails> SaveStudent([FromBody] StudentDetails saveStudent)
        {
            var result = _dataProvider.SaveStudentDetails(saveStudent);
            var listOfStd = _dataProvider.GetStudentDetails();
            return listOfStd;

        }

        [HttpPost]
        [Route("deletestudent")]
        public StudentDetails DeleteStudent([FromBody] string studentId)
        {
            var result = new StudentDetails();// _dataProvider.SaveStudentDetails(saveStudent);
            return result;

        }
    }



}

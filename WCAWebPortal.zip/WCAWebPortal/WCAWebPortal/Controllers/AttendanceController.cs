﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;
using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text.Json;
using System.Text.Json.Serialization;
using System.Threading.Tasks;
using WCAWebPortal.Data;
using WCAWebPortal.Models;

namespace WCAWebPortal.Controllers
{
    [ApiController]
    [Route("Attendance")]
    public class AttendanceController : ControllerBase
    {
        private readonly ILogger<AttendanceController> _logger;
        IDataProvider _dataProvider;

        public AttendanceController(ILogger<AttendanceController> logger, IDataProvider dataProvider)
        {
            _logger = logger;
            _dataProvider = dataProvider;
        }

        [HttpGet]
        public IEnumerable<StudentAttendance> Get()
        {
            var result = _dataProvider.GetAttendanceDetails();
            return result; 
        } 

        [HttpPost]
        [Route("saveattendance")]
        public IEnumerable<StudentAttendance> SaveAttendance([FromBody] JsonElement attendanceDeatils)
        {   
            var result = _dataProvider.SaveAttendanceDetails(attendanceDeatils);
            return result;

        } 
    }



}

﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;
using WCAWebPortal.Data;
using WCAWebPortal.Models;

namespace WCAWebPortal.Controllers
{
    public class AttendanceController : Controller
    {
        private readonly ILogger<AttendanceController> _logger;
        IDataProvider _dataProvider;

       
        public AttendanceController(ILogger<AttendanceController> logger, IDataProvider dataProvider)
        {
            _logger = logger;
            _dataProvider = dataProvider;
        }

        // GET: AttendanceController
        public ActionResult Index()
        { 
                var result = _dataProvider.GetAttendanceDetails();
            return View(result);
        }

        [HttpPost]
        public ActionResult SaveAttendance(IFormCollection model)
        {
           
            var result = _dataProvider.GetAttendanceDetails();
            return View(result);
        }


        [HttpGet]
        public JsonResult GetAttendanceDetails(string txtClassId, string txtDate)
        {
            var response = _dataProvider.GetAttendanceDetails();
            //var json = new JavaScriptSerializer().Serialize(obj);
            var jsonData = new
            {
                data = response
            };

            return Json(jsonData, System.Web.Mvc.JsonRequestBehavior.AllowGet);
        }


        // GET: AttendanceController/Details/5
        public ActionResult Details(int id)
        {
            return View();
        }

        // GET: AttendanceController/Create
        public ActionResult Create()
        {
            return View();
        }

        // POST: AttendanceController/Create
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Create(IFormCollection collection)
        {
            try
            {
                return RedirectToAction(nameof(Index));
            }
            catch
            {
                return View();
            }
        }

        // GET: AttendanceController/Edit/5
        public ActionResult Edit(int id)
        {
            return View();
        }

        // POST: AttendanceController/Edit/5
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Edit(int id, IFormCollection collection)
        {
            try
            {
                return RedirectToAction(nameof(Index));
            }
            catch
            {
                return View();
            }
        }

        // GET: AttendanceController/Delete/5
        public ActionResult Delete(int id)
        {
            return View();
        }

        // POST: AttendanceController/Delete/5
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Delete(int id, IFormCollection collection)
        {
            try
            {
                return RedirectToAction(nameof(Index));
            }
            catch
            {
                return View();
            }
        }
    }
}

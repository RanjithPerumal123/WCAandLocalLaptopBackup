﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;
using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Threading.Tasks;
using WCAWebPortal.Models;
using Microsoft.Extensions.Configuration;
using WCAWebPortal.Data;

namespace WCAWebPortal.Controllers
{
    public class LoginController : Controller
    {
        private readonly ILogger<HomeController> _logger;
        private IConfiguration Configuration;
        DbContextHelp dbContextHelp;
        public LoginController(ILogger<HomeController> logger, IConfiguration _configuration)
        {
            _logger = logger;
            Configuration = _configuration;
           
        } 
        public IActionResult Index()
        {
            string connString = Configuration.GetConnectionString("DefaultConnection");
            dbContextHelp = new DbContextHelp(connString);
            IDataProvider obj = new DataProvider(dbContextHelp);
            var result=obj.GetUserLogin("1");
            return View(result);
        }

        public IActionResult Privacy()
        {
            return View();
        }

        [ResponseCache(Duration = 0, Location = ResponseCacheLocation.None, NoStore = true)]
        public IActionResult Error()
        {
            return View(new ErrorViewModel { RequestId = Activity.Current?.Id ?? HttpContext.TraceIdentifier });
        }
    }
}

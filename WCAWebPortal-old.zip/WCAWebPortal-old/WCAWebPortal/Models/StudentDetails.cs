﻿using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Threading.Tasks;

namespace WCAWebPortal.Models
{
    [Table("StudentDetails")]
    [Keyless]
    public class StudentDetails
    {
        [Column("StudentId")]
        [Key]
        public int StudentId { get; set; }

        [Column("ParentDetailId")]
        public int ParentDetailId { get; set; }

        [Column("ClassId")]
        public int ClassId { get; set; }

        [Column("FirstName")]
        public string FirstName { get; set; }

        [Column("LastName")]
        public string LastName { get; set; }
        [Column("DateOfBirth")]
        public DateTime DateOfBirth { get; set; }

        [Column("EmailId")]
        public string EmailId { get; set; }

        [Column("PhoneNumber")]
        public string PhoneNumber { get; set; }

        [Column("WantsToBe")]
        public string WantsToBe { get; set; }

        [Column("AbountMe")]
        public string AbountMe { get; set; }


        [Column("CreatedDateTime")]
        public DateTime CreatedDateTime { get; set; }


        [Column("CreatedBy")]
        public string CreatedBy { get; set; }


        [Column("UpdatedDateTime")]
        public DateTime? UpdatedDateTime { get; set; }

        [Column("UpdatedBy")]
        public string UpdatedBy { get; set; }

        [Column("IsActive")]
        public string IsActive { get; set; }
    }
}

﻿using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Threading.Tasks;

namespace WCAWebPortal.Models
{
    //[Table("AttendanceDeatils")]
    [Keyless]
    public class AttendanceDeatils
    {
        //[Column("StudentId")]
        [Key]
        public int StudentId { get; set; }

        //[Column("AttendanceId")]        
        public int? AttendanceId { get; set; } 

        //[Column("FirstName")]
        public string FirstName { get; set; }

        //[Column("LastName")]
        public string LastName { get; set; }

        //[Column("ClassName")]
        public string ClassName { get; set; }

        //[Column("DateOfBirth")]
        public DateTime DateOfBirth { get; set; }

        public bool IsAttendanceFlag { get; set; }

    }
}

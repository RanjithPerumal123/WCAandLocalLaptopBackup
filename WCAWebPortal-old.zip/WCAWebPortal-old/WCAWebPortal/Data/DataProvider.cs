﻿using Microsoft.Data.SqlClient;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using WCAWebPortal.Models;

namespace WCAWebPortal.Data
{
    public class DataProvider : IDataProvider
    {
        private readonly DbContextHelp _context;
        public DataProvider(DbContextHelp dbContextHelp)
        {
            this._context = dbContextHelp;
        }
        public UserLogin GetUserLogin(string userid)
        {
            return _context.UserLogins.Where(x => x.UserId == userid).FirstOrDefault();
        }

        public List<StudentDetails> GetStudentDetails()
        {
            return _context.StudentDetails.ToList();
        }

        public List<AttendanceDeatils> GetAttendanceDetails()
        {
            //return _context.AttendanceDeatils.ToList();


            List<AttendanceDeatils> list=new List<AttendanceDeatils>();
            string sql = "EXEC GetAttendanceDeatils";
            list = _context.AttendanceDeatils.FromSqlRaw(sql).ToList();
            return list;

        }


        private bool _disposed;

        protected virtual void Dispose(bool disposing)
        {
            if (!_disposed)
            {
                if (disposing)
                {
                    _context.Dispose();
                }
            }
            _disposed = true;
        }

        public void Dispose()
        {
            Dispose(true);
            GC.SuppressFinalize(this);
        }


    }
}

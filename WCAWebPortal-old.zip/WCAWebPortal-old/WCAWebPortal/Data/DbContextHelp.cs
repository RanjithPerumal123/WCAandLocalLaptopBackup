﻿using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using WCAWebPortal.Models;

namespace WCAWebPortal.Data
{
    public class DbContextHelp : DbContext
    {
        private readonly string connectionString= "Server=wcadatabase.database.windows.net;Initial Catalog=wcadatabase;Persist Security Info=False;User ID=wcadatabase;Password=P@ssw0rd123.;MultipleActiveResultSets=False;Encrypt=True;TrustServerCertificate=False;Connection Timeout=30";

        public DbContextHelp(DbContextOptions<DbContextHelp> options)
           : base(options)
        { }
        public DbContextHelp(string connectionString)
        {
            this.connectionString = connectionString;
        }
        public DbSet<UserLogin> UserLogins { get; set; }

        public DbSet<StudentDetails> StudentDetails { get; set; }

        public DbSet<AttendanceDeatils> AttendanceDeatils { get; set; }

        protected override void OnConfiguring(DbContextOptionsBuilder optionsBuilder)
        {
            optionsBuilder.UseSqlServer(connectionString);
        }

         
    }
}

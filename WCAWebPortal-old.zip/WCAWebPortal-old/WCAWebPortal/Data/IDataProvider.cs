﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using WCAWebPortal.Models;

namespace WCAWebPortal.Data
{
    public interface IDataProvider : IDisposable
    {
        public UserLogin GetUserLogin(string userid);

        public List<StudentDetails> GetStudentDetails();

        public List<AttendanceDeatils> GetAttendanceDetails();

    }
}
